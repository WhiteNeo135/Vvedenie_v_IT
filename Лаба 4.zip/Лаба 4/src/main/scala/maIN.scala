import Typeclasses.{Reversable, Smash}

object main
{
    def main(args: Array[String]): Unit =
    {
        var a=1
        var b=2
        var c= 3.0
        var d= 4.0
        println(Smash.smash(a,b))
        println(Smash.smash(c, d))
        println(Smash.smash("type", "class"))
        println(Reversable.reverse("test"))
    }
}